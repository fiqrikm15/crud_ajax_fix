<?php
class Book extends CI_Controller{
	function __construct(){
		parent:: __construct();
		$this->load->model("book_model");
	}	
	
	function index(){
		$data['books'] = $this->book_model->get_allBooks();
		$this->load->view('daftar_buku', $data);
	}
	
	function book_add(){
		$data = array(
			'title' => $this->input->post('title'),
			'author' => $this->input->post('author'),
			'category' => $this->input->post('category'),
			'price' => $this->input->post('price')
		);
		
		$insert = $this->book_model->book_add($data);
		echo json_encode(array("status" => true));
	}
	
	function book_edit($id){
		$data = $this->book_model->get_byId($id);
		echo json_encode($data);
	}
	
	function book_update(){
		$data = array(
			'title' => $this->input->post('title'),
			'author' => $this->input->post('author'),
			'category' => $this->input->post('category'),
			'price' => $this->input->post('price'),
		);
		
		$this->book_model->update_book(array("id_lb" => $this->input->post("id_lb")), $data);
		echo json_encode(array("status" => true));
	}
	
	function book_delete($id){
		$this->book_model->delete_byId($id);
		json_encode(array("status" => true));
	}
}